package com.dicoding.fragmenttofragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button


class Fragment1 : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_1, container, false)

        // ini Tombol untuk Berpindah ke Fragment 2
        val buttonNavigate = view.findViewById<Button>(R.id.To_Fragment2)
        buttonNavigate.setOnClickListener {

            //ini sebagai remot yang mengatur fragment apa yang ingin di tampilkan
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, Fragment2())
                .addToBackStack(null)
                .commit()
        }

        return view
    }
}