package com.dicoding.fragmenttofragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button

class Fragment2 : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Menampilkan Fragment kedua
        return inflater.inflate(R.layout.fragment_2, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
         val buttonNavigate = view.findViewById<Button>(R.id.To_Fragment1)

        buttonNavigate.setOnClickListener {
            //ini sebagai remot yang mengatur fragment apa yang ingin di tampilkan
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, Fragment1())
                .addToBackStack(null)
                .commit()
        }
    }
}
